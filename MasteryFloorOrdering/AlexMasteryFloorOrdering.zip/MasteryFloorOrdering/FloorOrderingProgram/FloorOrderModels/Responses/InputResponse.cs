﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloorOrderModels.Responses
{
    public class DateCheckResponse : Response
    {

    }

    public class NameCheckResponse : Response
    {

    }

    public class StateInputCheckResponse : Response
    {

    }

    public class ProductInputCheckResponse : Response
    {

    }

    public class AreaCheckResponse : Response
    {

    }
}
